import { useState } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import PhoneFrame from './components/PhoneFrame';
import Home from './pages/Home';
import AddExpense from './pages/AddExpense';
import Mirror from './pages/Mirror';
import Intervention from './pages/Intervention';
import Report from './pages/Report';
import Profile from './pages/Profile';

function AnimatedRoutes({ dark, setDark }: { dark: boolean; setDark: (v: boolean) => void }) {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait" initial={false}>
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<Home />} />
        <Route path="/add-expense" element={<AddExpense />} />
        <Route path="/mirror" element={<Mirror />} />
        <Route path="/intervention" element={<Intervention />} />
        <Route path="/report" element={<Report />} />
        <Route path="/profile" element={<Profile dark={dark} setDark={setDark} />} />
      </Routes>
    </AnimatePresence>
  );
}

function App() {
  const [dark, setDark] = useState(false);

  return (
    <PhoneFrame dark={dark}>
      <AnimatedRoutes dark={dark} setDark={setDark} />
    </PhoneFrame>
  );
}

export default App;
