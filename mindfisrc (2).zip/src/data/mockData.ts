// Shared mock/fake data for the MindFi hackathon prototype.
// No backend — everything here is static, in-memory fixture data.

export type Emotion =
  | 'سعيد'
  | 'محايد'
  | 'حزين'
  | 'متوتر'
  | 'ممل'
  | 'غاضب'
  | 'قلق'
  | 'أكافئ نفسي';

export const emotionOptions: { emoji: string; label: Emotion }[] = [
  { emoji: '😊', label: 'سعيد' },
  { emoji: '😐', label: 'محايد' },
  { emoji: '😔', label: 'حزين' },
  { emoji: '😰', label: 'متوتر' },
  { emoji: '😴', label: 'ممل' },
  { emoji: '😡', label: 'غاضب' },
  { emoji: '😟', label: 'قلق' },
  { emoji: '🎁', label: 'أكافئ نفسي' },
];

export const categories = ['طعام', 'تسوق', 'مواصلات', 'ترفيه', 'فواتير'];

export interface Transaction {
  id: string;
  merchant: string;
  category: string;
  amount: number;
  emoji: string;
  emotion: string;
  time: string;
}

export const recentTransactions: Transaction[] = [
  {
    id: 't1',
    merchant: 'قهوة',
    category: 'طعام',
    amount: 24,
    emoji: '😊',
    emotion: 'سعادة',
    time: 'اليوم، 8:32 ص',
  },
  {
    id: 't2',
    merchant: 'توصيل طعام',
    category: 'طعام',
    amount: 92,
    emoji: '😔',
    emotion: 'توتر',
    time: 'أمس، 9:47 م',
  },
  {
    id: 't3',
    merchant: 'تسوق',
    category: 'تسوق',
    amount: 315,
    emoji: '😴',
    emotion: 'ملل',
    time: 'أمس، 4:10 م',
  },
];

export const behaviorTimeline = [
  { day: 'الإثنين', from: 'توتر', to: 'طلب طعام' },
  { day: 'الأربعاء', from: 'ملل', to: 'تسوق' },
  { day: 'الجمعة', from: 'سعادة', to: 'قهوة' },
];

export const homeStats = {
  behaviorAwareness: 84,
  aiConfidence: 91,
  monthlySpend: 4350,
  savedAmount: 980,
  emotionalSpendIndex: 72,
  topTrigger: { label: 'التوتر', emoji: '😔' },
};

// Emotion distribution used on Mirror + Report screens (kept consistent).
export const emotionDistribution = [
  { name: 'التوتر', value: 45, color: '#F59E0B' },
  { name: 'الملل', value: 25, color: '#8B5CF6' },
  { name: 'السعادة', value: 15, color: '#2EC4B6' },
  { name: 'محايد', value: 15, color: '#9CA3AF' },
];

// 30-day spending series for the Mirror screen line chart.
export const spending30Days = Array.from({ length: 30 }, (_, i) => {
  const base = 120 + Math.sin(i / 3) * 60 + (i % 7 === 5 ? 140 : 0);
  const noise = (i * 37) % 50;
  return {
    day: `${i + 1}`,
    amount: Math.max(20, Math.round(base + noise - 25)),
  };
});

// 7-day series for the Weekly Report chart.
export const weeklySpending = [
  { day: 'السبت', amount: 310 },
  { day: 'الأحد', amount: 420 },
  { day: 'الإثنين', amount: 260 },
  { day: 'الثلاثاء', amount: 480 },
  { day: 'الأربعاء', amount: 200 },
  { day: 'الخميس', amount: 390 },
  { day: 'الجمعة', amount: 150 },
];

// Heatmap: 7 days x 4 time blocks, intensity 0-100 (emotion-driven spending).
export const heatmapDays = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
export const heatmapBlocks = ['صباح', 'ظهر', 'مساء', 'ليل'];
export const heatmapData: number[][] = [
  [10, 25, 60, 35],
  [15, 30, 45, 20],
  [20, 40, 85, 55],
  [30, 20, 50, 40],
  [10, 35, 90, 65],
  [25, 45, 70, 50],
  [40, 30, 55, 20],
];

export const behaviorPatterns = [
  {
    id: 'p1',
    from: 'التوتر',
    to: 'طلبات الطعام',
    icon: 'UtensilsCrossed',
  },
  {
    id: 'p2',
    from: 'الملل',
    to: 'التسوق الإلكتروني',
    icon: 'ShoppingBag',
  },
  {
    id: 'p3',
    from: 'القلق',
    to: 'مشتريات صغيرة متكررة',
    icon: 'Repeat',
  },
];

export const aiInsights = {
  homeInsight:
    'لاحظ الذكاء الاصطناعي نمطًا متكررًا: يزداد إنفاقك بنسبة 38٪ بعد أيام العمل المجهدة.',
  mirrorSnapshot:
    'أنت تميل إلى الإنفاق عند الشعور بالتوتر. معظم مشترياتك العاطفية تحدث في المساء بعد ساعات العمل.',
  mirrorReflection:
    'عند الشعور بالتوتر، تصبح احتمالية طلب الطعام أعلى بمقدار 3.4 مرات مقارنة بالأوقات الأخرى.',
  addExpenseSuccess:
    'شكرًا لك. لقد ظهر هذا الشعور سابقًا في عمليات شراء مشابهة.',
  weeklySummary:
    'هذا الأسبوع قمت بعدد أقل من عمليات الشراء الناتجة عن التوتر وأظهرت وعيًا ماليًا أفضل مقارنة بالأسبوع الماضي.',
  interventionWarning:
    'اكتشف الذكاء الاصطناعي أن هذه العملية تشبه عمليات إنفاق عاطفي سابقة.',
  interventionImpact:
    'المستخدمون الذين أخروا الشراء لمدة 24 ساعة خفّضوا الإنفاق الاندفاعي بنسبة 31٪.',
};

export const weeklyReportStats = {
  saved: 420,
  impulsiveAvoided: 6,
  topTrigger: 'التوتر',
  behaviorImprovement: 18,
  lastMonthAwareness: 71,
  currentMonthAwareness: 84,
};

export const achievements = [
  {
    id: 'a1',
    title: '3 أيام بدون إنفاق اندفاعي',
    icon: 'Trophy',
  },
  {
    id: 'a2',
    title: 'تحسن في الوعي المالي',
    icon: 'Medal',
  },
  {
    id: 'a3',
    title: 'تحقيق الهدف الادخاري',
    icon: 'Star',
  },
];

export const coachingSuggestions = [
  { id: 'c1', label: 'خذ جولة قصيرة', icon: 'Footprints' },
  { id: 'c2', label: 'اشرب كوب ماء', icon: 'GlassWater' },
  { id: 'c3', label: 'راجع هدفك المالي', icon: 'Target' },
  { id: 'c4', label: 'انتظر 10 دقائق قبل اتخاذ القرار', icon: 'Timer' },
];

export const userProfile = {
  name: 'سارة أحمد',
  greeting: 'سارة',
  behaviorAwareness: 84,
  financialAwarenessLevel: 'متقدم',
};
