import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  ShieldAlert,
  Footprints,
  GlassWater,
  Target,
  Timer,
  TrendingDown,
  Clock,
  Bookmark,
  Shuffle,
} from 'lucide-react';
import PageTransition from '../components/PageTransition';
import GlassCard from '../components/GlassCard';
import { coachingSuggestions, aiInsights } from '../data/mockData';

const coachIcons: Record<string, typeof Footprints> = {
  Footprints,
  GlassWater,
  Target,
  Timer,
};

export default function Intervention() {
  const navigate = useNavigate();
  const [choice, setChoice] = useState<string | null>(null);

  const handleChoice = (label: string) => {
    setChoice(label);
    setTimeout(() => navigate('/'), 1600);
  };

  return (
    <PageTransition>
      <div className="h-full flex flex-col relative bg-gradient-to-b from-white to-purple/5 dark:from-[#0f1522] dark:to-[#171126]">
        <div className="flex-1 overflow-y-auto no-scrollbar px-4 pt-8 pb-8">
          <div className="flex justify-end mb-2">
            <button
              onClick={() => navigate('/')}
              className="w-9 h-9 rounded-full bg-navy/5 dark:bg-white/10 flex items-center justify-center text-navy dark:text-white"
            >
              <X size={18} />
            </button>
          </div>

          {/* Warning banner */}
          <div className="flex flex-col items-center text-center mb-5">
            <motion.div
              animate={{ boxShadow: ['0 0 0px rgba(139,92,246,0.4)', '0 0 32px rgba(139,92,246,0.5)', '0 0 0px rgba(139,92,246,0.4)'] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-16 h-16 rounded-full bg-gradient-to-br from-warning to-purple flex items-center justify-center text-white mb-3"
            >
              <ShieldAlert size={30} />
            </motion.div>
            <h1 className="text-lg font-extrabold text-navy dark:text-white mb-1.5">تنبيه سلوكي ذكي</h1>
            <p className="text-sm text-navy/60 dark:text-white/60 leading-relaxed px-2">
              {aiInsights.interventionWarning}
            </p>
          </div>

          {/* Stats */}
          <GlassCard className="p-4 mb-5 flex flex-col gap-4">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-semibold text-navy/60 dark:text-white/60">احتمالية الإنفاق العاطفي</span>
                <span className="text-sm font-extrabold text-warning">87%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-navy/10 dark:bg-white/10 overflow-hidden">
                <div className="h-full rounded-full bg-gradient-to-l from-warning to-purple" style={{ width: '87%' }} />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-navy/60 dark:text-white/60">الشعور المتوقع</span>
              <span className="text-sm font-bold text-navy dark:text-white">التوتر 😰</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-navy/60 dark:text-white/60">مستوى الخطورة</span>
              <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-warning/15 text-warning">مرتفع</span>
            </div>
          </GlassCard>

          <h2 className="text-base font-bold text-navy dark:text-white text-center mb-4">
            هل تحتاج فعلًا إلى هذا الشراء اليوم؟
          </h2>

          {/* Action buttons */}
          <div className="flex flex-col gap-3 mb-6">
            <button
              onClick={() => handleChoice('إكمال الشراء')}
              className="w-full py-3.5 rounded-full font-bold text-navy dark:text-white border-2 border-navy/15 dark:border-white/20"
            >
              إكمال الشراء
            </button>
            <button
              onClick={() => handleChoice('الانتظار 24 ساعة')}
              className="relative w-full py-3.5 rounded-full font-extrabold text-white bg-gradient-to-l from-teal to-navy shadow-glow flex items-center justify-center gap-2"
            >
              <Clock size={16} />
              الانتظار 24 ساعة
              <span className="absolute -top-2.5 left-3 bg-success text-white text-[9px] font-bold px-2 py-0.5 rounded-full">
                موصى به
              </span>
            </button>
            <button
              onClick={() => handleChoice('الحفظ لاحقًا')}
              className="w-full py-3.5 rounded-full font-bold text-navy dark:text-white bg-navy/5 dark:bg-white/10 flex items-center justify-center gap-2"
            >
              <Bookmark size={16} />
              الحفظ لاحقًا
            </button>
            <button
              onClick={() => handleChoice('اقتراح بديل')}
              className="w-full py-3.5 rounded-full font-bold text-navy dark:text-white bg-navy/5 dark:bg-white/10 flex items-center justify-center gap-2"
            >
              <Shuffle size={16} />
              اقتراح بديل
            </button>
          </div>

          {/* Coaching */}
          <h3 className="text-sm font-bold text-navy dark:text-white mb-3">توجيه ذكي فوري</h3>
          <div className="grid grid-cols-2 gap-3 mb-5">
            {coachingSuggestions.map((c) => {
              const Icon = coachIcons[c.icon];
              return (
                <GlassCard key={c.id} className="p-3 flex flex-col items-center text-center gap-2">
                  <span className="w-9 h-9 rounded-full bg-teal/15 text-teal flex items-center justify-center">
                    <Icon size={16} />
                  </span>
                  <span className="text-xs font-semibold text-navy dark:text-white leading-snug">{c.label}</span>
                </GlassCard>
              );
            })}
          </div>

          {/* Impact card */}
          <GlassCard className="p-4 border-r-4 border-r-success flex items-start gap-3">
            <span className="w-9 h-9 rounded-full bg-success/15 text-success flex items-center justify-center shrink-0">
              <TrendingDown size={18} />
            </span>
            <p className="text-sm leading-relaxed text-navy/70 dark:text-white/70">{aiInsights.interventionImpact}</p>
          </GlassCard>
        </div>

        <AnimatePresence>
          {choice && (
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 40 }}
              className="absolute bottom-6 inset-x-4 z-50"
            >
              <div className="bg-navy text-white rounded-2xl px-4 py-3 text-center text-sm font-bold shadow-glow">
                تم اختيار: {choice} ✓
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </PageTransition>
  );
}
