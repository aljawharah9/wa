import { useState } from 'react';
import {
  Target,
  Bell,
  Lock,
  Globe,
  Moon,
  Landmark,
  Info,
  ChevronLeft,
  Sparkles,
  BellRing,
  HeartHandshake,
} from 'lucide-react';
import PageTransition from '../components/PageTransition';
import GlassCard from '../components/GlassCard';
import SectionTitle from '../components/SectionTitle';
import BottomNav from '../components/BottomNav';
import ProgressRing from '../components/ProgressRing';
import { userProfile } from '../data/mockData';

interface SwitchProps {
  checked: boolean;
  onChange: () => void;
}

function Switch({ checked, onChange }: SwitchProps) {
  return (
    <button
      onClick={onChange}
      className={[
        'relative w-11 h-6 rounded-full transition-colors duration-300 shrink-0',
        checked ? 'bg-gradient-to-l from-teal to-navy' : 'bg-navy/15 dark:bg-white/15',
      ].join(' ')}
    >
      <span
        className={[
          'absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform duration-300',
          checked ? 'translate-x-[-1.375rem]' : 'translate-x-[-0.125rem]',
        ].join(' ')}
        style={{ right: 0 }}
      />
    </button>
  );
}

interface SettingsRowProps {
  icon: React.ReactNode;
  label: string;
  trailing?: React.ReactNode;
  muted?: boolean;
  onClick?: () => void;
}

function SettingsRow({ icon, label, trailing, muted = false, onClick }: SettingsRowProps) {
  return (
    <button
      onClick={onClick}
      disabled={!onClick}
      className={[
        'w-full flex items-center gap-3 py-3.5 px-1 border-b border-navy/5 dark:border-white/10 last:border-b-0',
        muted ? 'opacity-50' : '',
      ].join(' ')}
    >
      <span className="w-9 h-9 rounded-full bg-navy/5 dark:bg-white/10 text-navy dark:text-white flex items-center justify-center shrink-0">
        {icon}
      </span>
      <span className="flex-1 text-sm font-semibold text-navy dark:text-white text-right">{label}</span>
      {trailing}
    </button>
  );
}

export default function Profile({ dark, setDark }: { dark: boolean; setDark: (v: boolean) => void }) {
  const [smartGuidance, setSmartGuidance] = useState(true);
  const [smartAlerts, setSmartAlerts] = useState(true);
  const [emotionTracking, setEmotionTracking] = useState(true);

  return (
    <PageTransition>
      <div className="h-full flex flex-col">
        <div className="flex-1 overflow-y-auto no-scrollbar px-4 pt-8 pb-32">
          <h1 className="text-xl font-extrabold text-navy dark:text-white mb-5">الملف الشخصي</h1>

          {/* Header */}
          <GlassCard className="p-5 flex items-center gap-4 mb-5">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-teal to-purple flex items-center justify-center text-white text-xl font-extrabold shadow-glow shrink-0">
              سا
            </div>
            <div className="flex-1">
              <h2 className="text-base font-extrabold text-navy dark:text-white">{userProfile.name}</h2>
              <span className="inline-block mt-1 px-2.5 py-1 rounded-full bg-purple/15 text-purple text-[11px] font-bold">
                مستوى الوعي المالي: {userProfile.financialAwarenessLevel}
              </span>
            </div>
            <ProgressRing value={userProfile.behaviorAwareness} size={56} strokeWidth={6} color="#2EC4B6" />
          </GlassCard>

          {/* Settings */}
          <SectionTitle title="الإعدادات" />
          <GlassCard className="p-3 mb-5">
            <SettingsRow icon={<Target size={16} />} label="الأهداف المالية" trailing={<ChevronLeft size={16} className="text-navy/30 dark:text-white/30" />} onClick={() => {}} />
            <SettingsRow icon={<Bell size={16} />} label="الإشعارات" trailing={<ChevronLeft size={16} className="text-navy/30 dark:text-white/30" />} onClick={() => {}} />
            <SettingsRow icon={<Lock size={16} />} label="الخصوصية" trailing={<ChevronLeft size={16} className="text-navy/30 dark:text-white/30" />} onClick={() => {}} />
            <SettingsRow
              icon={<Globe size={16} />}
              label="اللغة"
              trailing={<span className="text-xs text-navy/40 dark:text-white/40">العربية</span>}
              onClick={() => {}}
            />
            <SettingsRow
              icon={<Moon size={16} />}
              label="الوضع الداكن"
              trailing={<Switch checked={dark} onChange={() => setDark(!dark)} />}
            />
            <SettingsRow
              icon={<Landmark size={16} />}
              label="الخدمات البنكية المفتوحة"
              trailing={<span className="text-[10px] font-bold text-navy/40 dark:text-white/40 bg-navy/5 dark:bg-white/10 px-2 py-1 rounded-full">قريبًا</span>}
              muted
            />
          </GlassCard>

          {/* Behavioral preferences */}
          <SectionTitle title="التفضيلات السلوكية" />
          <GlassCard className="p-3 mb-5">
            <SettingsRow
              icon={<Sparkles size={16} />}
              label="تفعيل التوجيه الذكي"
              trailing={<Switch checked={smartGuidance} onChange={() => setSmartGuidance((v) => !v)} />}
            />
            <SettingsRow
              icon={<BellRing size={16} />}
              label="تفعيل التنبيهات الذكية"
              trailing={<Switch checked={smartAlerts} onChange={() => setSmartAlerts((v) => !v)} />}
            />
            <SettingsRow
              icon={<HeartHandshake size={16} />}
              label="تفعيل تتبع المشاعر"
              trailing={<Switch checked={emotionTracking} onChange={() => setEmotionTracking((v) => !v)} />}
            />
          </GlassCard>

          {/* About */}
          <GlassCard className="p-3 mb-4">
            <SettingsRow icon={<Info size={16} />} label="حول MindFi" trailing={<ChevronLeft size={16} className="text-navy/30 dark:text-white/30" />} onClick={() => {}} />
          </GlassCard>

          <p className="text-center text-[11px] text-navy/30 dark:text-white/30">الإصدار: 1.0 MVP</p>
        </div>
        <BottomNav />
      </div>
    </PageTransition>
  );
}
