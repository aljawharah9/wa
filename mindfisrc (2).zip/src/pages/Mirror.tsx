import { PieChart, Pie, Cell, ResponsiveContainer, AreaChart, Area, XAxis, Tooltip } from 'recharts';
import { motion } from 'framer-motion';
import { Sparkles, UtensilsCrossed, ShoppingBag, Repeat, ArrowLeft, Smile, Brain, Wallet } from 'lucide-react';
import PageTransition from '../components/PageTransition';
import GlassCard from '../components/GlassCard';
import SectionTitle from '../components/SectionTitle';
import BottomNav from '../components/BottomNav';
import ProgressRing from '../components/ProgressRing';
import {
  emotionDistribution,
  spending30Days,
  heatmapDays,
  heatmapBlocks,
  heatmapData,
  behaviorPatterns,
  aiInsights,
  homeStats,
} from '../data/mockData';

const patternIcons: Record<string, typeof UtensilsCrossed> = {
  UtensilsCrossed,
  ShoppingBag,
  Repeat,
};

function heatColor(intensity: number) {
  // 0-100 -> gradient from teal(low) -> purple(mid) -> navy(high)
  if (intensity < 30) return 'rgba(46, 196, 182, 0.25)';
  if (intensity < 50) return 'rgba(46, 196, 182, 0.55)';
  if (intensity < 70) return 'rgba(139, 92, 246, 0.55)';
  if (intensity < 85) return 'rgba(139, 92, 246, 0.8)';
  return 'rgba(29, 53, 87, 0.9)';
}

const dominant = emotionDistribution.reduce((a, b) => (a.value > b.value ? a : b));

export default function Mirror() {
  return (
    <PageTransition>
      <div className="h-full flex flex-col">
        <div className="flex-1 overflow-y-auto no-scrollbar px-4 pt-8 pb-32">
          <h1 className="text-xl font-extrabold text-navy dark:text-white">المرآة السلوكية</h1>
          <p className="text-xs text-navy/50 dark:text-white/50 mt-1 mb-5">
            نظرة عميقة على علاقتك بالمال ومشاعرك
          </p>

          {/* Snapshot */}
          <GlassCard gradient className="p-5 mb-5 relative overflow-hidden">
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl" />
            <div className="flex items-center gap-2 mb-2">
              <span className="flex items-center justify-center w-8 h-8 rounded-full bg-white/15">
                <Sparkles size={16} />
              </span>
              <h3 className="font-bold">لقطة سلوكية ذكية</h3>
            </div>
            <p className="text-sm leading-relaxed text-white/90">{aiInsights.mirrorSnapshot}</p>
          </GlassCard>

          {/* Emotion distribution donut */}
          <SectionTitle title="توزيع المشاعر" subtitle="حسب عمليات الشراء المسجّلة" />
          <GlassCard className="p-4 mb-5">
            <div className="relative h-52">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={emotionDistribution}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={3}
                    stroke="none"
                  >
                    {emotionDistribution.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v: any, n: any) => [`${v}%`, n] as [string, string]} />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-2xl font-extrabold text-navy dark:text-white">{dominant.value}%</span>
                <span className="text-xs text-navy/50 dark:text-white/50">{dominant.name} (الأبرز)</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-3">
              {emotionDistribution.map((e) => (
                <div key={e.name} className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: e.color }} />
                  <span className="text-xs text-navy/70 dark:text-white/70">
                    {e.name} · {e.value}%
                  </span>
                </div>
              ))}
            </div>
          </GlassCard>

          {/* Heatmap */}
          <SectionTitle title="خريطة محفزات الإنفاق" subtitle="الإنفاق العاطفي حسب اليوم والوقت" />
          <GlassCard className="p-4 mb-5">
            <div className="overflow-x-auto no-scrollbar">
              <div className="min-w-[300px]">
                <div className="grid grid-cols-[40px_repeat(4,1fr)] gap-1 mb-1">
                  <div />
                  {heatmapBlocks.map((b) => (
                    <div key={b} className="text-[10px] text-center text-navy/50 dark:text-white/50 font-semibold">
                      {b}
                    </div>
                  ))}
                </div>
                {heatmapDays.map((day, rowIdx) => (
                  <div key={day} className="grid grid-cols-[40px_repeat(4,1fr)] gap-1 mb-1">
                    <div className="text-[10px] text-navy/50 dark:text-white/50 font-semibold flex items-center">{day}</div>
                    {heatmapData[rowIdx].map((val, colIdx) => (
                      <div
                        key={colIdx}
                        className="h-7 rounded-md"
                        style={{ backgroundColor: heatColor(val) }}
                        title={`${val}%`}
                      />
                    ))}
                  </div>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-center gap-3 mt-3">
              <span className="text-[10px] text-navy/50 dark:text-white/50">أقل</span>
              <div className="flex gap-0.5">
                {[15, 40, 60, 80, 95].map((v) => (
                  <span key={v} className="w-4 h-3 rounded-sm" style={{ backgroundColor: heatColor(v) }} />
                ))}
              </div>
              <span className="text-[10px] text-navy/50 dark:text-white/50">أعلى</span>
            </div>
          </GlassCard>

          {/* Line chart */}
          <SectionTitle title="الإنفاق خلال آخر 30 يومًا" />
          <GlassCard className="p-4 mb-5">
            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={spending30Days} margin={{ top: 5, right: 5, left: 5, bottom: 0 }}>
                  <defs>
                    <linearGradient id="mirrorArea" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#8B5CF6" stopOpacity={0.45} />
                      <stop offset="100%" stopColor="#2EC4B6" stopOpacity={0.02} />
                    </linearGradient>
                    <linearGradient id="mirrorStroke" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#2EC4B6" />
                      <stop offset="100%" stopColor="#8B5CF6" />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="day" hide />
                  <Tooltip formatter={(v: any) => [`${v} ر.س`, 'الإنفاق'] as [string, string]} labelFormatter={(l) => `اليوم ${l}`} />
                  <Area
                    type="monotone"
                    dataKey="amount"
                    stroke="url(#mirrorStroke)"
                    strokeWidth={3}
                    fill="url(#mirrorArea)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </GlassCard>

          {/* Pattern cards */}
          <SectionTitle title="أنماط سلوكية مكتشفة" />
          <div className="flex flex-col gap-3 mb-5">
            {behaviorPatterns.map((p) => {
              const Icon = patternIcons[p.icon];
              return (
                <GlassCard key={p.id} className="p-4 flex items-center gap-3">
                  <span className="flex items-center justify-center w-10 h-10 rounded-full bg-purple/10 text-purple shrink-0">
                    <Icon size={18} />
                  </span>
                  <span className="text-sm font-bold text-navy dark:text-white flex-1">{p.from}</span>
                  <ArrowLeft size={16} className="text-navy/30 dark:text-white/30" />
                  <span className="text-sm font-bold text-navy dark:text-white flex-1 text-left">{p.to}</span>
                </GlassCard>
              );
            })}
          </div>

          {/* Rings */}
          <div className="grid grid-cols-2 gap-3 mb-5">
            <GlassCard className="p-4 flex flex-col items-center gap-2">
              <ProgressRing value={homeStats.behaviorAwareness} color="#2EC4B6" size={84} />
              <span className="text-xs font-semibold text-navy/60 dark:text-white/60 text-center">مؤشر الوعي السلوكي</span>
            </GlassCard>
            <GlassCard className="p-4 flex flex-col items-center gap-2">
              <ProgressRing value={homeStats.aiConfidence} color="#8B5CF6" size={84} />
              <span className="text-xs font-semibold text-navy/60 dark:text-white/60 text-center">ثقة التنبؤ</span>
            </GlassCard>
          </div>

          {/* AI reflection */}
          <GlassCard className="p-4 mb-5 border-r-4 border-r-purple">
            <div className="flex items-center gap-2 mb-1.5">
              <Sparkles size={15} className="text-purple" />
              <h3 className="text-sm font-bold text-navy dark:text-white">تأمل الذكاء الاصطناعي</h3>
            </div>
            <p className="text-sm leading-relaxed text-navy/70 dark:text-white/70">{aiInsights.mirrorReflection}</p>
          </GlassCard>

          {/* Diagram */}
          <SectionTitle title="مسار القرار" subtitle="من المشاعر إلى الإنفاق" />
          <GlassCard className="p-5 mb-5">
            <div className="flex items-center justify-between">
              <div className="flex flex-col items-center gap-2">
                <span className="w-14 h-14 rounded-full bg-warning/15 text-warning flex items-center justify-center">
                  <Smile size={24} />
                </span>
                <span className="text-xs font-bold text-navy dark:text-white">مشاعر</span>
              </div>
              <motion.div
                animate={{ opacity: [0.4, 1, 0.4] }}
                transition={{ duration: 1.8, repeat: Infinity }}
                className="flex-1 h-0.5 bg-gradient-to-l from-warning to-purple mx-1"
              />
              <div className="flex flex-col items-center gap-2">
                <span className="w-14 h-14 rounded-full bg-purple/15 text-purple flex items-center justify-center">
                  <Brain size={24} />
                </span>
                <span className="text-xs font-bold text-navy dark:text-white">قرار</span>
              </div>
              <motion.div
                animate={{ opacity: [0.4, 1, 0.4] }}
                transition={{ duration: 1.8, repeat: Infinity, delay: 0.4 }}
                className="flex-1 h-0.5 bg-gradient-to-l from-purple to-navy mx-1"
              />
              <div className="flex flex-col items-center gap-2">
                <span className="w-14 h-14 rounded-full bg-navy/15 text-navy dark:bg-white/15 dark:text-white flex items-center justify-center">
                  <Wallet size={24} />
                </span>
                <span className="text-xs font-bold text-navy dark:text-white">إنفاق</span>
              </div>
            </div>
          </GlassCard>
        </div>
        <BottomNav />
      </div>
    </PageTransition>
  );
}
