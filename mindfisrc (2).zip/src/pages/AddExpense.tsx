import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, CheckCircle2, Sparkles } from 'lucide-react';
import PageTransition from '../components/PageTransition';
import GlassCard from '../components/GlassCard';
import EmotionChip from '../components/EmotionChip';
import { categories, emotionOptions, aiInsights } from '../data/mockData';

export default function AddExpense() {
  const navigate = useNavigate();
  const [amount, setAmount] = useState('');
  const [merchant, setMerchant] = useState('');
  const [category, setCategory] = useState(categories[0]);
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [emotion, setEmotion] = useState<string | null>(null);
  const [intensity, setIntensity] = useState(5);
  const [note, setNote] = useState('');
  const [saved, setSaved] = useState(false);

  const canSave = amount.trim().length > 0 && merchant.trim().length > 0 && emotion;

  return (
    <PageTransition>
      <div className="h-full flex flex-col">
        <div className="flex-1 overflow-y-auto no-scrollbar px-4 pt-8 pb-10">
          <div className="flex items-center gap-3 mb-6">
            <button
              onClick={() => navigate(-1)}
              className="w-9 h-9 rounded-full bg-navy/5 dark:bg-white/10 flex items-center justify-center text-navy dark:text-white"
            >
              <ChevronRight size={18} />
            </button>
            <h1 className="text-lg font-extrabold text-navy dark:text-white">إضافة مصروف</h1>
          </div>

          <GlassCard className="p-5 flex flex-col gap-6">
            {/* Amount */}
            <div>
              <label className="text-xs font-semibold text-navy/60 dark:text-white/60 mb-2 block">المبلغ</label>
              <div className="flex items-center justify-center gap-2 bg-navy/[0.03] dark:bg-white/5 rounded-2xl py-5">
                <input
                  type="number"
                  inputMode="decimal"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0"
                  className="w-1/2 bg-transparent text-center text-4xl font-extrabold text-navy dark:text-white outline-none placeholder:text-navy/20"
                />
                <span className="text-lg font-bold text-navy/40 dark:text-white/40">ر.س</span>
              </div>
            </div>

            {/* Merchant */}
            <div>
              <label className="text-xs font-semibold text-navy/60 dark:text-white/60 mb-2 block">التاجر</label>
              <input
                type="text"
                value={merchant}
                onChange={(e) => setMerchant(e.target.value)}
                placeholder="مثال: ستاربكس"
                className="w-full bg-navy/[0.03] dark:bg-white/5 rounded-xl px-4 py-3 text-sm font-semibold text-navy dark:text-white outline-none focus:ring-2 ring-teal placeholder:text-navy/30"
              />
            </div>

            {/* Category */}
            <div>
              <label className="text-xs font-semibold text-navy/60 dark:text-white/60 mb-2 block">الفئة</label>
              <div className="flex flex-wrap gap-2">
                {categories.map((c) => (
                  <button
                    key={c}
                    onClick={() => setCategory(c)}
                    className={[
                      'px-4 py-2 rounded-full text-xs font-bold transition-all',
                      category === c
                        ? 'bg-gradient-to-br from-navy to-purple text-white shadow-glow'
                        : 'bg-navy/[0.04] dark:bg-white/5 text-navy/60 dark:text-white/60',
                    ].join(' ')}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            {/* Date */}
            <div>
              <label className="text-xs font-semibold text-navy/60 dark:text-white/60 mb-2 block">التاريخ</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-navy/[0.03] dark:bg-white/5 rounded-xl px-4 py-3 text-sm font-semibold text-navy dark:text-white outline-none focus:ring-2 ring-teal"
              />
            </div>

            {/* Emotion before purchase */}
            <div>
              <label className="text-sm font-bold text-navy dark:text-white mb-3 block">كيف كان شعورك قبل الشراء؟</label>
              <div className="grid grid-cols-4 gap-2">
                {emotionOptions.map((opt) => (
                  <EmotionChip
                    key={opt.label}
                    emoji={opt.emoji}
                    label={opt.label}
                    selected={emotion === opt.label}
                    onClick={() => setEmotion(opt.label)}
                  />
                ))}
              </div>
            </div>

            {/* Intensity */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-bold text-navy dark:text-white">ما مدى قوة هذا الشعور؟</label>
                <span className="w-8 h-8 rounded-full bg-gradient-to-br from-teal to-purple text-white text-sm font-extrabold flex items-center justify-center">
                  {intensity}
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={10}
                value={intensity}
                onChange={(e) => setIntensity(Number(e.target.value))}
                className="w-full accent-purple"
              />
              <div className="flex justify-between text-[10px] text-navy/40 dark:text-white/40 mt-1">
                <span>ضعيف</span>
                <span>قوي جدًا</span>
              </div>
            </div>

            {/* Note */}
            <div>
              <label className="text-xs font-semibold text-navy/60 dark:text-white/60 mb-2 block">
                ماذا حدث قبل عملية الشراء؟ <span className="text-navy/30">(اختياري)</span>
              </label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={3}
                placeholder="اكتب ملاحظتك هنا..."
                className="w-full bg-navy/[0.03] dark:bg-white/5 rounded-xl px-4 py-3 text-sm text-navy dark:text-white outline-none focus:ring-2 ring-teal resize-none placeholder:text-navy/30"
              />
            </div>

            <motion.button
              whileTap={{ scale: 0.97 }}
              disabled={!canSave}
              onClick={() => setSaved(true)}
              className={[
                'w-full py-4 rounded-full font-extrabold text-white transition-all',
                canSave ? 'bg-gradient-to-l from-navy to-teal shadow-glow' : 'bg-navy/20 cursor-not-allowed',
              ].join(' ')}
            >
              حفظ العملية
            </motion.button>
          </GlassCard>
        </div>

        <AnimatePresence>
          {saved && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 bg-navy/60 backdrop-blur-sm flex items-center justify-center p-6"
            >
              <motion.div
                initial={{ scale: 0.8, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                transition={{ type: 'spring', stiffness: 200, damping: 18 }}
                className="w-full"
              >
                <GlassCard className="p-6 flex flex-col items-center text-center gap-4">
                  <motion.div
                    initial={{ scale: 0, rotate: -90 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: 0.1, type: 'spring', stiffness: 260, damping: 14 }}
                    className="w-16 h-16 rounded-full bg-success/15 text-success flex items-center justify-center"
                  >
                    <CheckCircle2 size={36} />
                  </motion.div>
                  <h3 className="text-lg font-extrabold text-navy dark:text-white">تم حفظ العملية بنجاح</h3>

                  <div className="w-full bg-gradient-to-br from-navy to-purple rounded-2xl p-4 text-white text-right flex gap-2 items-start">
                    <Sparkles size={18} className="shrink-0 mt-0.5" />
                    <p className="text-sm leading-relaxed">{aiInsights.addExpenseSuccess}</p>
                  </div>

                  <motion.button
                    whileTap={{ scale: 0.96 }}
                    onClick={() => navigate('/')}
                    className="w-full py-3.5 rounded-full font-extrabold text-white bg-gradient-to-l from-navy to-teal shadow-glow"
                  >
                    العودة إلى الرئيسية
                  </motion.button>
                </GlassCard>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </PageTransition>
  );
}
