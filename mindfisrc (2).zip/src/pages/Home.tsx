import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Plus, Sparkles, TrendingUp, Wallet, PiggyBank, Gauge, ShieldCheck, Coffee, UtensilsCrossed, ShoppingBag } from 'lucide-react';
import PageTransition from '../components/PageTransition';
import GlassCard from '../components/GlassCard';
import StatCard from '../components/StatCard';
import SectionTitle from '../components/SectionTitle';
import BottomNav from '../components/BottomNav';
import ProgressRing from '../components/ProgressRing';
import { behaviorTimeline, homeStats, recentTransactions, aiInsights } from '../data/mockData';

const categoryIcon: Record<string, typeof Coffee> = {
  قهوة: Coffee,
  'توصيل طعام': UtensilsCrossed,
  تسوق: ShoppingBag,
};

export default function Home() {
  const navigate = useNavigate();

  return (
    <PageTransition>
      <div className="h-full flex flex-col">
        <div className="flex-1 overflow-y-auto no-scrollbar px-4 pt-10 pb-32">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-xs text-navy/50 dark:text-white/50">أهلًا بعودتك</p>
              <h1 className="text-xl font-extrabold text-navy dark:text-white">صباح الخير، سارة</h1>
            </div>
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-teal to-purple flex items-center justify-center text-white font-bold shadow-glow shrink-0">
              سا
            </div>
          </div>

          {/* Stats grid */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <StatCard
              label="مؤشر الوعي السلوكي"
              value={`${homeStats.behaviorAwareness}%`}
              accent="#2EC4B6"
              icon={<Gauge size={16} />}
              extra={<ProgressRing value={homeStats.behaviorAwareness} size={40} strokeWidth={5} color="#2EC4B6" label=" " />}
            />
            <StatCard
              label="ثقة الذكاء الاصطناعي"
              value={`${homeStats.aiConfidence}%`}
              accent="#8B5CF6"
              icon={<ShieldCheck size={16} />}
              extra={<ProgressRing value={homeStats.aiConfidence} size={40} strokeWidth={5} color="#8B5CF6" label=" " />}
            />
            <StatCard
              label="الإنفاق الشهري"
              value={`${homeStats.monthlySpend.toLocaleString('ar-SA')} ر.س`}
              accent="#1D3557"
              icon={<Wallet size={16} />}
            />
            <StatCard
              label="المبلغ المُوفَّر"
              value={`${homeStats.savedAmount.toLocaleString('ar-SA')} ر.س`}
              accent="#22C55E"
              icon={<PiggyBank size={16} />}
            />
            <StatCard
              label="مؤشر الإنفاق العاطفي"
              value={`${homeStats.emotionalSpendIndex}%`}
              accent="#F59E0B"
              icon={<TrendingUp size={16} />}
            />
            <StatCard
              label="أبرز محفز عاطفي"
              value={`${homeStats.topTrigger.label} ${homeStats.topTrigger.emoji}`}
              accent="#F59E0B"
            />
          </div>

          {/* AI insight card */}
          <GlassCard gradient className="p-5 mb-5 relative overflow-hidden">
            <div className="absolute -top-8 -left-8 w-32 h-32 bg-white/10 rounded-full blur-2xl" />
            <div className="flex items-center gap-2 mb-2">
              <span className="flex items-center justify-center w-8 h-8 rounded-full bg-white/15">
                <Sparkles size={16} />
              </span>
              <h3 className="font-bold">تحليل ذكي</h3>
            </div>
            <p className="text-sm leading-relaxed text-white/90">{aiInsights.homeInsight}</p>
          </GlassCard>

          {/* Behavior timeline */}
          <SectionTitle title="الخط الزمني السلوكي" subtitle="آخر الأنماط المرصودة هذا الأسبوع" />
          <GlassCard className="p-4 mb-5">
            <div className="flex flex-col gap-3">
              {behaviorTimeline.map((item, idx) => (
                <div key={item.day} className="flex items-center gap-3">
                  <div className="flex flex-col items-center">
                    <span className="w-2.5 h-2.5 rounded-full bg-gradient-to-br from-teal to-purple" />
                    {idx !== behaviorTimeline.length - 1 && <span className="w-px h-6 bg-navy/10 dark:bg-white/10" />}
                  </div>
                  <div className="flex-1 flex items-center justify-between">
                    <span className="text-xs font-semibold text-navy/60 dark:text-white/60 w-14">{item.day}</span>
                    <span className="text-sm font-bold text-navy dark:text-white">
                      {item.from} ← {item.to}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>

          {/* Recent activity */}
          <SectionTitle title="النشاط الأخير" />
          <div className="flex flex-col gap-3">
            {recentTransactions.map((tx) => {
              const Icon = categoryIcon[tx.merchant] ?? Wallet;
              const isStressTx = tx.emotion === 'توتر';
              return (
                <motion.button
                  key={tx.id}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => (isStressTx ? navigate('/intervention') : undefined)}
                  className="text-right"
                >
                  <GlassCard className="p-3 flex items-center gap-3">
                    <span className="flex items-center justify-center w-10 h-10 rounded-full bg-navy/5 dark:bg-white/10 text-navy dark:text-white shrink-0">
                      <Icon size={18} />
                    </span>
                    <div className="flex-1">
                      <p className="text-sm font-bold text-navy dark:text-white">{tx.merchant}</p>
                      <p className="text-xs text-navy/50 dark:text-white/50">{tx.time}</p>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className="text-sm font-extrabold text-navy dark:text-white">{tx.amount} ر.س</span>
                      <span className="text-xs">
                        {tx.emoji} {tx.emotion}
                      </span>
                    </div>
                  </GlassCard>
                </motion.button>
              );
            })}
            <p className="text-[11px] text-navy/40 dark:text-white/40 text-center mt-1">
              نصيحة: اضغط على عملية "توصيل طعام" لتجربة التدخل الذكي
            </p>
          </div>
        </div>

        {/* FAB */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          whileHover={{ scale: 1.05 }}
          onClick={() => navigate('/add-expense')}
          className="absolute bottom-24 left-5 z-30 w-14 h-14 rounded-full bg-gradient-to-br from-navy to-teal text-white flex items-center justify-center shadow-glow"
        >
          <Plus size={26} />
        </motion.button>

        <BottomNav />
      </div>
    </PageTransition>
  );
}
