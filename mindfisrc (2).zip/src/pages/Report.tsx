import { AreaChart, Area, PieChart, Pie, Cell, ResponsiveContainer, XAxis, Tooltip } from 'recharts';
import { PiggyBank, ShieldOff, TrendingUp, Sparkles, Trophy, Medal, Star } from 'lucide-react';
import PageTransition from '../components/PageTransition';
import GlassCard from '../components/GlassCard';
import SectionTitle from '../components/SectionTitle';
import BottomNav from '../components/BottomNav';
import ProgressRing from '../components/ProgressRing';
import StatCard from '../components/StatCard';
import {
  weeklyReportStats,
  weeklySpending,
  emotionDistribution,
  aiInsights,
  achievements,
} from '../data/mockData';

const achievementIcons: Record<string, typeof Trophy> = { Trophy, Medal, Star };

export default function Report() {
  return (
    <PageTransition>
      <div className="h-full flex flex-col">
        <div className="flex-1 overflow-y-auto no-scrollbar px-4 pt-8 pb-32">
          <h1 className="text-xl font-extrabold text-navy dark:text-white mb-1">التقرير الأسبوعي</h1>
          <p className="text-xs text-navy/50 dark:text-white/50 mb-5">ملخص أدائك المالي والسلوكي هذا الأسبوع</p>

          {/* Stats grid */}
          <div className="grid grid-cols-2 gap-3 mb-5">
            <StatCard
              label="المبلغ المُوفَّر"
              value={`${weeklyReportStats.saved} ر.س`}
              accent="#22C55E"
              icon={<PiggyBank size={16} />}
            />
            <StatCard
              label="عمليات اندفاعية تم تجنبها"
              value={`${weeklyReportStats.impulsiveAvoided}`}
              accent="#2EC4B6"
              icon={<ShieldOff size={16} />}
            />
            <StatCard label="أبرز محفز عاطفي" value={weeklyReportStats.topTrigger} accent="#F59E0B" />
            <StatCard
              label="تحسن السلوك المالي"
              value={`+${weeklyReportStats.behaviorImprovement}%`}
              accent="#22C55E"
              icon={<TrendingUp size={16} />}
            />
          </div>

          {/* Weekly spending chart */}
          <SectionTitle title="منحنى الإنفاق الأسبوعي" />
          <GlassCard className="p-4 mb-5">
            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={weeklySpending} margin={{ top: 5, right: 5, left: 5, bottom: 0 }}>
                  <defs>
                    <linearGradient id="reportArea" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#1D3557" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="#2EC4B6" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="day" tick={{ fontSize: 10, fill: '#1D3557' }} axisLine={false} tickLine={false} />
                  <Tooltip formatter={(v: any) => [`${v} ر.س`, 'الإنفاق'] as [string, string]} />
                  <Area type="monotone" dataKey="amount" stroke="#1D3557" strokeWidth={3} fill="url(#reportArea)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </GlassCard>

          {/* Emotion distribution */}
          <SectionTitle title="توزيع المشاعر" />
          <GlassCard className="p-4 mb-5">
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={emotionDistribution} dataKey="value" nameKey="name" innerRadius={45} outerRadius={68} paddingAngle={3} stroke="none">
                    {emotionDistribution.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v: any, n: any) => [`${v}%`, n] as [string, string]} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {emotionDistribution.map((e) => (
                <div key={e.name} className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: e.color }} />
                  <span className="text-xs text-navy/70 dark:text-white/70">
                    {e.name} · {e.value}%
                  </span>
                </div>
              ))}
            </div>
          </GlassCard>

          {/* Progress ring comparison */}
          <SectionTitle title="مقارنة الوعي المالي" subtitle="الشهر الماضي مقابل الشهر الحالي" />
          <GlassCard className="p-4 mb-5 flex items-center justify-around">
            <div className="flex flex-col items-center gap-2">
              <ProgressRing value={weeklyReportStats.lastMonthAwareness} color="#9CA3AF" size={80} />
              <span className="text-xs font-semibold text-navy/60 dark:text-white/60">الشهر الماضي</span>
            </div>
            <div className="flex flex-col items-center gap-2 relative">
              <span className="absolute -top-3 bg-success text-white text-[9px] font-bold px-2 py-0.5 rounded-full">
                +{weeklyReportStats.behaviorImprovement}%
              </span>
              <ProgressRing value={weeklyReportStats.currentMonthAwareness} color="#22C55E" size={92} />
              <span className="text-xs font-bold text-navy dark:text-white">الشهر الحالي</span>
            </div>
          </GlassCard>

          {/* AI Weekly summary */}
          <GlassCard gradient className="p-5 mb-5 relative overflow-hidden">
            <div className="absolute -top-8 -left-8 w-32 h-32 bg-white/10 rounded-full blur-2xl" />
            <div className="flex items-center gap-2 mb-2">
              <span className="flex items-center justify-center w-8 h-8 rounded-full bg-white/15">
                <Sparkles size={16} />
              </span>
              <h3 className="font-bold">ملخص الذكاء الاصطناعي الأسبوعي</h3>
            </div>
            <p className="text-sm leading-relaxed text-white/90">{aiInsights.weeklySummary}</p>
          </GlassCard>

          {/* Achievements */}
          <SectionTitle title="الإنجازات" />
          <div className="grid grid-cols-3 gap-3">
            {achievements.map((a) => {
              const Icon = achievementIcons[a.icon];
              return (
                <div
                  key={a.id}
                  className="relative overflow-hidden rounded-[20px] p-4 flex flex-col items-center text-center gap-2 bg-gradient-to-br from-warning/15 via-purple/10 to-teal/15 border border-white/60 shadow-glass"
                >
                  <div className="absolute inset-0 bg-gradient-to-l from-transparent via-white/40 to-transparent bg-[length:200%_100%] animate-shine pointer-events-none" />
                  <span className="w-10 h-10 rounded-full bg-white/70 text-warning flex items-center justify-center relative z-10">
                    <Icon size={20} />
                  </span>
                  <span className="text-[11px] font-bold text-navy relative z-10 leading-snug">{a.title}</span>
                </div>
              );
            })}
          </div>
        </div>
        <BottomNav />
      </div>
    </PageTransition>
  );
}
