import type { ReactNode } from 'react';

interface SectionTitleProps {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}

export default function SectionTitle({ title, subtitle, action }: SectionTitleProps) {
  return (
    <div className="flex items-center justify-between mb-3">
      <div>
        <h2 className="text-base font-bold text-navy dark:text-white">{title}</h2>
        {subtitle && <p className="text-xs text-navy/50 dark:text-white/50 mt-0.5">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}
