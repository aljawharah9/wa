interface EmotionChipProps {
  emoji: string;
  label: string;
  selected?: boolean;
  onClick?: () => void;
}

export default function EmotionChip({ emoji, label, selected = false, onClick }: EmotionChipProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={[
        'flex flex-col items-center justify-center gap-1 rounded-2xl py-3 px-2 border transition-all duration-200 select-none',
        selected
          ? 'bg-gradient-to-br from-teal/20 to-purple/20 border-teal ring-2 ring-teal scale-105 shadow-glow'
          : 'bg-white/60 dark:bg-white/5 border-navy/10 dark:border-white/10 hover:scale-[1.03] active:scale-95',
      ].join(' ')}
    >
      <span className="text-2xl leading-none">{emoji}</span>
      <span
        className={[
          'text-[11px] font-semibold',
          selected ? 'text-navy dark:text-white' : 'text-navy/60 dark:text-white/60',
        ].join(' ')}
      >
        {label}
      </span>
    </button>
  );
}
