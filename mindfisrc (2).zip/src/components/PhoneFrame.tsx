import type { ReactNode } from 'react';

interface PhoneFrameProps {
  children: ReactNode;
  dark: boolean;
}

export default function PhoneFrame({ children, dark }: PhoneFrameProps) {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-[#eef0f4] py-6 px-2">
      <div className={dark ? 'dark' : ''}>
        <div className="relative mx-auto" style={{ width: 402, maxWidth: '100vw' }}>
          <div className="relative rounded-[48px] border-[10px] border-[#111318] bg-[#111318] shadow-2xl overflow-hidden" style={{ height: 860, maxHeight: '92vh' }}>
            {/* Notch */}
            <div className="absolute top-0 inset-x-0 z-40 flex justify-center pointer-events-none">
              <div className="w-32 h-6 bg-[#111318] rounded-b-2xl" />
            </div>
            {/* Screen */}
            <div className="phone-content relative w-full h-full bg-white dark:bg-[#0f1522] overflow-hidden rounded-[38px]">
              {children}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
