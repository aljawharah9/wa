import { Home, Sparkles, BarChart3, User } from 'lucide-react';
import { NavLink } from 'react-router-dom';

const navItems = [
  { to: '/', label: 'الرئيسية', icon: Home },
  { to: '/mirror', label: 'المرآة', icon: Sparkles },
  { to: '/report', label: 'التقارير', icon: BarChart3 },
  { to: '/profile', label: 'الملف الشخصي', icon: User },
];

export default function BottomNav() {
  return (
    <nav className="absolute bottom-0 inset-x-0 z-30 px-3 pb-3 pt-1">
      <div className="flex items-center justify-between rounded-[20px] border border-white/60 dark:border-white/10 bg-white/70 dark:bg-[#0f1522]/80 backdrop-blur-xl shadow-glass px-2 py-2">
        {navItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              [
                'flex flex-1 flex-col items-center justify-center gap-1 py-1.5 rounded-2xl transition-all duration-200',
                isActive ? 'text-white bg-gradient-to-br from-navy to-purple shadow-glow' : 'text-navy/50 dark:text-white/50',
              ].join(' ')
            }
          >
            <Icon size={20} strokeWidth={2.2} />
            <span className="text-[10px] font-semibold">{label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
