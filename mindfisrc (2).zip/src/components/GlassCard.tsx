import type { HTMLAttributes, ReactNode } from 'react';

interface GlassCardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  className?: string;
  gradient?: boolean;
}

export default function GlassCard({
  children,
  className = '',
  gradient = false,
  ...rest
}: GlassCardProps) {
  return (
    <div
      className={[
        'rounded-[20px] border backdrop-blur-xl shadow-glass',
        gradient
          ? 'bg-gradient-to-br from-[#1D3557]/95 via-[#3B2E6B]/90 to-[#8B5CF6]/90 border-white/10 text-white'
          : 'bg-white/70 dark:bg-white/5 border-white/60 dark:border-white/10',
        className,
      ].join(' ')}
      {...rest}
    >
      {children}
    </div>
  );
}
