import type { ReactNode } from 'react';
import { motion } from 'framer-motion';

export default function PageTransition({ children }: { children: ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 16 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -16 }}
      transition={{ duration: 0.28, ease: 'easeInOut' }}
      className="h-full"
    >
      {children}
    </motion.div>
  );
}
