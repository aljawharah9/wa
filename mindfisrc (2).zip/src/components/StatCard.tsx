import type { ReactNode } from 'react';
import GlassCard from './GlassCard';

interface StatCardProps {
  icon?: ReactNode;
  label: string;
  value: string;
  accent?: string;
  extra?: ReactNode;
}

export default function StatCard({ icon, label, value, accent = '#1D3557', extra }: StatCardProps) {
  return (
    <GlassCard className="p-4 flex flex-col justify-between gap-2 min-h-[104px]">
      <div className="flex items-center justify-between">
        <span className="text-xs text-navy/60 dark:text-white/60 font-medium leading-snug">{label}</span>
        {icon && (
          <span
            className="flex items-center justify-center w-8 h-8 rounded-full shrink-0"
            style={{ backgroundColor: `${accent}1A`, color: accent }}
          >
            {icon}
          </span>
        )}
      </div>
      <div className="flex items-end justify-between">
        <span className="text-lg font-extrabold text-navy dark:text-white">{value}</span>
        {extra}
      </div>
    </GlassCard>
  );
}
